import { useState, useEffect } from 'react'
import './App.css'

const API = 'http://localhost:5000/api/workouts'

function WorkoutForm({ onAdd }) {
  const [exerciseName, setExerciseName] = useState('')
  const [duration, setDuration] = useState('')
  const [calories, setCalories] = useState('')
  const [date, setDate] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    const payload = {
      exerciseName: exerciseName.trim(),
      duration: duration ? parseInt(duration, 10) : 0,
      calories: calories ? parseInt(calories, 10) : 0,
      date: date || new Date().toISOString().slice(0, 10),
      completed: false,
    }

    try {
      const res = await fetch(API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!res.ok) throw new Error('Failed to save')
      const saved = await res.json()
      onAdd(saved)
      setExerciseName('')
      setDuration('')
      setCalories('')
      setDate('')
    } catch (err) {
      console.error(err)
      alert('Could not add workout')
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 16 }}>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <input required placeholder="Exercise name" value={exerciseName} onChange={e => setExerciseName(e.target.value)} />
        <input required type="number" min="0" placeholder="Duration (min)" value={duration} onChange={e => setDuration(e.target.value)} />
        <input required type="number" min="0" placeholder="Calories" value={calories} onChange={e => setCalories(e.target.value)} />
        <input type="date" value={date} onChange={e => setDate(e.target.value)} />
        <button type="submit">Add workout</button>
      </div>
    </form>
  )
}

function WorkoutList({ workouts, onDelete, onToggle }) {
  if (!workouts || workouts.length === 0) return <p>No workouts yet.</p>
  return (
    <div style={{ display: 'grid', gap: 12 }}>
      {workouts.map(w => (
        <div key={w.id || w._id || Math.random()} style={{ border: '1px solid #ddd', padding: 12, borderRadius: 6, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontWeight: 600 }}>{w.exerciseName || w.ExerciseName}</div>
            <div style={{ fontSize: 13, color: '#555' }}>{w.duration} min • {w.calories} kcal • {w.date?.slice(0,10) || w.date}</div>
            <div style={{ marginTop: 6, fontSize: 12 }}>{w.completed ? 'Progress: Done' : 'Progress: Incomplete'}</div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => onToggle(w)} style={{ background: w.completed ? '#4caf50' : '#ff9800', color: '#fff', border: 'none', padding: '6px 8px', borderRadius: 4 }}>
              {w.completed ? 'Completed' : 'Update Progress'}
            </button>
            <button onClick={() => onDelete(w)} style={{ background: '#e53935', color: '#fff', border: 'none', padding: '6px 8px', borderRadius: 4 }}>
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

export default function App() {
  const [workouts, setWorkouts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchWorkouts()
  }, [])

  async function fetchWorkouts() {
    setLoading(true)
    try {
      const res = await fetch(API)
      if (!res.ok) throw new Error('Failed to fetch')
      const data = await res.json()
      setWorkouts(Array.isArray(data) ? data : [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  function addLocalWorkout(workout) {
    setWorkouts(prev => [workout, ...prev])
  }

  async function handleDelete(workout) {
    const id = workout.id || workout._id
    if (!id) {
      setWorkouts(prev => prev.filter(w => w !== workout))
      return
    }
    try {
      const res = await fetch(`${API}/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Delete failed')
      setWorkouts(prev => prev.filter(w => (w.id || w._id) !== id))
    } catch (err) {
      console.error(err)
      alert('Could not delete workout')
    }
  }

  async function handleToggle(workout) {
    const id = workout.id
    const newCompleted = !workout.completed
    if (!id) {
      setWorkouts(prev => prev.map(w => (w === workout ? { ...w, completed: newCompleted } : w)))
      return
    }
    try {
      const res = await fetch(`${API}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed: newCompleted }),
      })
      if (!res.ok) throw new Error('Update failed')
      const updated = await res.json()
      setWorkouts(prev => prev.map(w => ((w.id || w._id) === id ? updated : w)))
    } catch (err) {
      console.error(err)
      alert('Could not update progress')
    }
  }

  return (
    <div style={{ padding: 20, maxWidth: 800, margin: '0 auto' }}>
      <h1 style={{ marginBottom: 8 }}>Fitness Tracker</h1>
      <WorkoutForm onAdd={addLocalWorkout} />
      {loading ? <p>Loading...</p> : <WorkoutList workouts={workouts} onDelete={handleDelete} onToggle={handleToggle} />}
    </div>
  )
}

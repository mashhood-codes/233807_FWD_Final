const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
     Id: {
    type: Number,
    required: true,
    unique: true 
  },
  Exercise: {
    type: String,
    required: true,
    trim: true,
    maxlength: 40
  },
  Duration: {
    type: Number,
    required: true,
    unique: true 
  },
  Calories: {
    type: Number,
    min: 0 
  },
  createdAt: {
    type: Date,
    default: Date.now 
  }
}, {
  timestamps: true 
});

userSchema.methods.findId = function() {
  return mongoose.model('User').find({ Id: this.Id });
};

module.exports = mongoose.model('User', userSchema);

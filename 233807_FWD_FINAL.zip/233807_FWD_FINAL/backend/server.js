import express from 'express'
import cors from 'cors'
import mongoose from 'mongoose'
import checkAtlasConnection from './db.js'

checkAtlasConnection();
const app = express()
const PORT = 5000
app.use(cors())
app.use(express.json())

const Schema = mongoose.Schema

const userSchema = new Schema({
  exerciseName: { type: String, required: true, trim: true, maxlength: 100 },
  duration: { type: Number, required: true, min: 0 },
  calories: { type: Number, min: 0, default: 0 },
  date: { type: Date, default: Date.now },
  completed: { type: Boolean, default: false }
}, { timestamps: true })

const UserExercise = mongoose.model('Workout', userSchema)

app.get('/', (req, res) => {
  return res.send('Welcome to Fitness Tracker Application')
})

app.get('/api/workouts', async (req, res) => {
  try {
    const workouts = await UserExercise.find().sort({ createdAt: -1 })
    res.json(workouts)
  } catch (err) {
    res.status(500).send('Failed to fetch workouts')
  }
})

app.post('/api/workouts', async (req, res) => {
  try {
    const body = req.body || {}
    const workout = new UserExercise({
      exerciseName: body.exerciseName || body.Exercise || body.ExerciseName,
      duration: body.duration || body.Duration,
      calories: body.calories || body.Calories,
      date: body.date || body.createdAt,
      completed: body.completed || false
    })
    const saved = await workout.save()
    res.status(201).json(saved)
  } catch (err) {
    res.status(400).send('Failed to parse or save workout')
  }
})

app.patch('/api/workouts/:id', async (req, res) => {
  try {
    const id = req.params.id
    const updates = req.body || {}
    const updated = await UserExercise.findByIdAndUpdate(id, updates, { new: true })
    if (!updated) return res.status(404).send('Not found')
    res.json(updated)
  } catch (err) {
    res.status(400).send('Failed to update')
  }
})

app.delete('/api/workouts/:id', async (req, res) => {
  try {
    const id = req.params.id
    const removed = await UserExercise.findByIdAndDelete(id)
    if (!removed) return res.status(404).send('Not found')
    res.json(removed)
  } catch (err) {
    res.status(400).send('Failed to remove')
  }
})

app.listen(PORT, () => {
  console.log('Server is up on listening http://localhost:' + PORT)
})
import mongoose from 'mongoose'

const uri = process.env.MONGO_URI || 'mongodb+srv://mashhood:Mashhood123@cluster0.1yvhtdk.mongodb.net/Cluster78579?retryWrites=true&w=majority'

async function checkAtlasConnection() {
  try {
    await mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true })
    console.log('Successfully connected to MongoDB Atlas!')
    return true
  } catch (error) {
    console.error('Failed to connect to MongoDB Atlas:', error)
    return false
  }
}

export default checkAtlasConnection